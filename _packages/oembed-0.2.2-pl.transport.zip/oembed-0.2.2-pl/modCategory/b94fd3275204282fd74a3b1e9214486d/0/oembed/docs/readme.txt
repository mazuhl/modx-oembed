--------------------
Snippet: oembed
--------------------
Version: 0.2.2
Since: February 08, 2010
Author: Oleh Burkhay <atma@atmaworks.com>

An oEmbed implementation for MODx Revolution. oEmbed format official site http://oembed.com/

Example call:
[[oembed? &url=`http://www.youtube.com/watch?v=nErbxJloM8s`]]

Demos and documentation:
https://www.github.com/mazuhl/modx-oembed/

--------------------
Plugin: oembed
--------------------
Version: 0.2.2
Since: February 13, 2010
Author: Oleh Burkhay <atma@atmaworks.com>

Ability to autoembed media via URLs in content for known providers.
